<?php

use App\Http\Controllers\AdvertisementController;
use App\Http\Controllers\AdvertisingStoreController;
use App\Http\Controllers\AgentController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ClothingStoreController;
use App\Http\Controllers\CosmeticsStoreController;

Route::post('/cosmetics/{shop:slug}/orders', [\App\Http\Controllers\CosmeticsCheckoutController::class, 'store'])->middleware('throttle:20,1')->name('cosmetics.orders.store');

use App\Http\Controllers\DistributorController;
use App\Http\Controllers\ElectronicsStoreController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\FrontAssetController;
use App\Http\Controllers\FrontController;
use App\Http\Controllers\FurnitureStoreController;
use App\Http\Controllers\FrontOrderController;
use App\Http\Controllers\MerchantPwaController;
use App\Http\Controllers\ModularServiceController;
use App\Http\Controllers\ModularServiceDashboardController;
use App\Http\Controllers\OfferPushSubscriptionController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\PushDeviceController;
use App\Http\Controllers\PushNotificationController;
use App\Http\Controllers\RaffleCardController;
use App\Http\Controllers\RealEstateController;
use App\Http\Controllers\RealEstateDashboardController;
use App\Http\Controllers\RestaurantController;
use App\Http\Controllers\RestaurantDriverController;
use App\Http\Controllers\RewardWheelController;
use App\Http\Controllers\SalonAppointmentController;
use App\Http\Controllers\ScreenController;
use App\Http\Controllers\SeoController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\ShopAppController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\ShopStoryController;
use App\Http\Controllers\TextToSpeechController;
use App\Http\Controllers\TranslationController;
use App\Http\Controllers\SweetsStoreController;
use App\Http\Controllers\VisitorRegistrationAdminController;
use App\Http\Controllers\VisitorRegistrationController;
use App\Http\Controllers\WebPushSubscriptionController;
use App\Models\AdminNotification;
use Illuminate\Support\Facades\Route;

Route::get('/robots.txt', [SeoController::class, 'robots'])->name('seo.robots');
Route::get('/restaurant-purchase-wheel/{order}', [\App\Http\Controllers\RestaurantPurchaseWheelController::class, 'show'])->middleware('signed')->name('restaurant.purchase-wheel.show');
Route::post('/restaurant-purchase-wheel/{order}/spin', [\App\Http\Controllers\RestaurantPurchaseWheelController::class, 'spin'])->middleware(['signed', 'throttle:20,1'])->name('restaurant.purchase-wheel.spin');
Route::get('/sitemap.xml', [SeoController::class, 'sitemap'])->name('seo.sitemap');
Route::get('/', [FrontController::class, 'index'])->name('home');
Route::get('/shop-stories/feed', [ShopStoryController::class, 'feed'])->name('shop-stories.feed');
Route::get('/shop-stories/media/{story}', [ShopStoryController::class, 'media'])->name('shop-stories.media');
Route::post('/shop-stories/{story}/view', [ShopStoryController::class, 'recordView'])
    ->middleware('throttle:120,1')
    ->name('shop-stories.view');
Route::middleware('auth')->group(function () {
    Route::get('/shop-stories/manage', [ShopStoryController::class, 'index'])->name('shop-stories.index');
    Route::post('/shop-stories/manage', [ShopStoryController::class, 'store'])->middleware('throttle:20,1')->name('shop-stories.store');
    Route::delete('/shop-stories/manage/{story}', [ShopStoryController::class, 'destroy'])->name('shop-stories.destroy');
});
Route::get('/front-assets/{file}', [FrontAssetController::class, 'show'])
    ->where('file', 'script\\.js|style\\.css|shop-stories\\.(js|css)|caravan-(?:demo\\.(?:js|css)|model\\.js|demo-poster\\.png)')
    ->name('front.assets');
Route::get('/images/real-estate-services/{file}', [FrontAssetController::class, 'realEstateServiceImage'])
    ->where('file', '[A-Za-z0-9_-]+\\.webp')
    ->name('real-estate.service-images');
// Fallback for hosts where Laravel's public directory and public_html are separate.
// The web server serves these paths directly when copied; otherwise Laravel serves
// the Git-managed files while preserving the service worker's root scope.
Route::get('/{file}', [FrontAssetController::class, 'show'])
    ->where('file', '(?:merchant-pwa(?:-sw)?|shop-pwa|offer-notifications)\\.js')
    ->name('merchant-pwa.asset');
Route::post('/offers/push/subscription', [OfferPushSubscriptionController::class, 'store'])
    ->middleware('throttle:20,1')
    ->name('offers.push.store');
Route::delete('/offers/push/subscription', [OfferPushSubscriptionController::class, 'destroy'])
    ->middleware('throttle:20,1')
    ->name('offers.push.destroy');
Route::post('/app/device-token', [PushDeviceController::class, 'store'])
    ->middleware('throttle:20,1')
    ->name('app.device-token.store');
Route::get('/shop-app/{shop:slug}', [ShopAppController::class, 'index'])->name('shop-app.index');
Route::get('/shop-app/{shop:slug}/install', [ShopAppController::class, 'install'])->name('shop-app.install');
Route::get('/shop-app/{shop:slug}/launch', [ShopAppController::class, 'launch'])->name('shop-app.launch');
Route::get('/shop-app/{shop:slug}/manifest.webmanifest', [ShopAppController::class, 'manifest'])->name('shop-app.manifest');
Route::get('/merchant-app', [MerchantPwaController::class, 'index'])->name('merchant-app.index');
Route::get('/merchant-app/launch/{shop:slug}', [MerchantPwaController::class, 'launch'])->name('merchant-app.launch');
Route::get('/merchant-app/manifest/{shop:slug}.webmanifest', [MerchantPwaController::class, 'manifest'])->name('merchant-app.manifest');
Route::get('/merchant-app/icon/{shop:slug}/{size}.png', [MerchantPwaController::class, 'icon'])
    ->whereIn('size', [192, 512])
    ->name('merchant-app.icon');
Route::get('/merchant-app/push/public-key', [WebPushSubscriptionController::class, 'publicKey'])
    ->middleware('throttle:30,1')
    ->name('merchant-app.push.public-key');
Route::middleware(['auth', 'throttle:30,1'])->group(function () {
    Route::post('/merchant-app/push/subscription', [WebPushSubscriptionController::class, 'store'])
        ->name('merchant-app.push.store');
    Route::delete('/merchant-app/push/subscription', [WebPushSubscriptionController::class, 'destroy'])
        ->name('merchant-app.push.destroy');
});
Route::get('/csrf-token', [FrontController::class, 'csrfToken'])
    ->middleware('throttle:30,1')
    ->name('csrf.refresh');
Route::get('/market', [FrontController::class, 'index'])->name('front.home');
Route::get('/front/shops/{shop}', [FrontController::class, 'index'])->name('front.shop');
Route::get('/stores/{shop:slug}', [FrontController::class, 'index'])->name('front.shop.slug');
Route::get('/restaurants/{shop:slug}', [RestaurantController::class, 'menu'])->name('restaurant.menu');
Route::post('/restaurants/{shop:slug}/customer-registration', [\App\Http\Controllers\RestaurantCustomerRegistrationController::class, 'store'])
    ->middleware('throttle:20,1')
    ->name('restaurant.customer-registration.store');
Route::post('/restaurants/{shop:slug}/signup-reward', [\App\Http\Controllers\ShopSignupRewardController::class, 'state'])
    ->middleware('throttle:30,1')->name('restaurant.signup-reward');
Route::get('/advertising/{shop:slug}', [AdvertisingStoreController::class, 'index'])->name('advertising.store');
Route::get('/electronics/{shop:slug}', [ElectronicsStoreController::class, 'index'])->name('electronics.store');
Route::get('/fashion/{shop:slug}', [ClothingStoreController::class, 'index'])->name('clothing.store');
Route::post('/fashion/{shop:slug}/photo-tryon', [\App\Http\Controllers\ClothingPhotoTryOnController::class, 'create'])->middleware('throttle:6,60,photo-tryon-create:')->name('clothing.photo-tryon');
Route::get('/fashion/{shop:slug}/photo-tryon/{job}', [\App\Http\Controllers\ClothingPhotoTryOnController::class, 'status'])->whereUuid('job')->middleware('throttle:60,1,photo-tryon-status:')->name('clothing.photo-tryon.status');
Route::get('/virtual-tryon/photo-demo', fn() => response()->file(base_path('public/images/virtual-tryon/photo-demo-before-after.png')))->name('virtual-tryon.photo-demo');
Route::get('/virtual-tryon/demo-garment', function () {
    $path = public_path('images/virtual-tryon/demo-ivory-navy-tee.png');

    abort_unless(is_file($path), 404);

    return response()->file($path, [
        'Content-Type' => 'image/png',
        'Cache-Control' => 'public, max-age=86400',
    ]);
})->name('virtual-tryon.demo-garment');
Route::get('/cosmetics/{shop:slug}', [CosmeticsStoreController::class, 'index'])->name('cosmetics.store');
Route::post('/cosmetics/{shop:slug}/watch-tryon', [\App\Http\Controllers\ClothingPhotoTryOnController::class, 'create'])->middleware('throttle:6,60,watch-tryon-create:')->name('watch.photo-tryon');
Route::get('/cosmetics/{shop:slug}/watch-tryon/{job}', [\App\Http\Controllers\ClothingPhotoTryOnController::class, 'status'])->whereUuid('job')->middleware('throttle:60,1,watch-tryon-status:')->name('watch.photo-tryon.status');
Route::get('/virtual-tryon/demo-watch', fn() => response()->file(base_path('public/images/virtual-tryon/demo-blue-watch.png')))->name('virtual-tryon.demo-watch');
Route::get('/sweets/{shop:slug}', [SweetsStoreController::class, 'index'])->name('sweets.store');
Route::get('/home-furniture/{shop:slug}', [FurnitureStoreController::class, 'index'])->name('furniture.store');
Route::get('/cosmetics/{shop:slug}/booking', [CosmeticsStoreController::class, 'booking'])->name('cosmetics.booking');
Route::get('/cosmetics/{shop:slug}/booking/availability', [SalonAppointmentController::class, 'availability'])->name('cosmetics.booking.availability');
Route::post('/cosmetics/{shop:slug}/booking', [SalonAppointmentController::class, 'store'])->name('cosmetics.booking.store');
Route::post('/electronics/{shop:slug}/compare/{product}', [ElectronicsStoreController::class, 'toggleCompare'])->name('electronics.compare.toggle');
Route::post('/electronics/{shop:slug}/compare-clear', [ElectronicsStoreController::class, 'clearCompare'])->name('electronics.compare.clear');
Route::get('/electronics/{shop:slug}/compare', [ElectronicsStoreController::class, 'compare'])->name('electronics.compare');
Route::get('/electronics/{shop:slug}/devices/{product:slug}', [ElectronicsStoreController::class, 'show'])->name('electronics.product');
Route::get('/real-estate/{shop:slug}', [RealEstateController::class, 'company'])->name('real-estate.company');
Route::get('/real-estate/{shop:slug}/services/{modularCategory:slug}', [ModularServiceController::class, 'category'])->name('real-estate.services.category');
Route::get('/real-estate/{shop:slug}/services/{modularCategory:slug}/{service:slug}', [ModularServiceController::class, 'show'])->name('real-estate.services.show');
Route::post('/real-estate/{shop:slug}/services/{modularCategory:slug}/{service:slug}/whatsapp', [ModularServiceController::class, 'whatsapp'])
    ->middleware('throttle:10,1')->name('real-estate.services.whatsapp');
Route::get('/real-estate/{shop:slug}/properties/{realEstateProperty:slug}', [RealEstateController::class, 'property'])->name('real-estate.property');
Route::get('/real-estate', [RealEstateController::class, 'index'])->name('real-estate.index');
Route::get('/real-estate-compare', [RealEstateController::class, 'compare'])->name('real-estate.compare');
Route::post('/real-estate/{shop:slug}/properties/{realEstateProperty:slug}/inquiries', [RealEstateController::class, 'inquiry'])
    ->middleware('throttle:10,1')->name('real-estate.inquiries.store');
Route::post('/real-estate-alerts', [RealEstateController::class, 'alert'])
    ->middleware('throttle:5,1')->name('real-estate.alerts.store');
Route::get('/real-estate/{shop:slug}/qr.svg', [RealEstateDashboardController::class, 'qr'])->name('real-estate.company.qr');
Route::post('/electronics/{shop}/orders', [ElectronicsStoreController::class, 'order'])->middleware('throttle:20,1')->name('electronics.orders.store');
Route::get('/restaurants/{shop:slug}/table/{tableCode}', [RestaurantController::class, 'menu'])->name('restaurant.table');
Route::post('/restaurants/{shop}/orders', [RestaurantController::class, 'storeOrder'])->middleware('throttle:30,1')->name('restaurant.orders.store');
Route::get('/restaurant-orders/{order}/tracking', [RestaurantController::class, 'track'])
    ->middleware(['signed', 'throttle:60,1'])
    ->name('restaurant.orders.track');
Route::get('/restaurant-tables/{table:code}/qr.svg', [RestaurantController::class, 'tableQr'])->name('restaurant.tables.qr');
Route::get('/distributor-stores/{distributor}', [FrontController::class, 'distributor'])->name('front.distributor');
Route::get('/marketer-stores/{marketer:tracking_code}', [FrontController::class, 'marketer'])->name('front.marketer');
Route::get('/marketer-wheel/{marketer:tracking_code}', [RewardWheelController::class, 'publicMarketerDirect'])->name('front.marketer.direct-wheel');
Route::post('/marketer-wheel/{marketer:tracking_code}/spin', [RewardWheelController::class, 'publicMarketerDirectSpin'])->name('front.marketer.direct-wheel.spin');
Route::view('/customer-login', 'front.customer_login')->name('customer.login');
Route::get('/tts/hebrew', [TextToSpeechController::class, 'hebrew'])->name('tts.hebrew');
Route::get('/tts/arabic', [TextToSpeechController::class, 'arabic'])->name('tts.arabic');
Route::post('/visitor-registrations', [VisitorRegistrationController::class, 'store'])->name('visitor-registrations.store');
Route::get('/visitor-registrations/status/{token}', [VisitorRegistrationController::class, 'status'])
    ->middleware('throttle:30,1')
    ->name('visitor-registrations.status');
Route::post('/front-orders', [FrontOrderController::class, 'store'])->name('front-orders.store');
Route::post('/raffle/check', [RaffleCardController::class, 'check'])->name('raffle.check');
Route::get('/raffle-card/{cardNumber}', [RaffleCardController::class, 'openCard'])->name('front.raffle-card.open');
Route::get('/front-orders/{order}/qr.svg', [FrontOrderController::class, 'qr'])->name('front-orders.qr');
Route::post('/front-orders/{order}/spin-reward', [FrontOrderController::class, 'spinReward'])->name('front-orders.spinReward');
Route::patch('/front-orders/{order}/reward', [FrontOrderController::class, 'reward'])->name('front-orders.reward');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.store');
    Route::get('/merchant-login', [AuthController::class, 'showMerchantLogin'])->name('merchant.login');
    Route::post('/merchant-login', [AuthController::class, 'merchantLogin'])
        ->middleware('throttle:10,1')
        ->name('merchant.login.store');
    Route::get('/merchant-register', [AuthController::class, 'showMerchantRegister'])->name('merchant.register');
    Route::post('/merchant-register', [AuthController::class, 'merchantRegister'])
        ->middleware('throttle:5,1')
        ->name('merchant.register.store');
    Route::get('/driver-login', [AuthController::class, 'showDriverLogin'])->name('driver.login');
    Route::post('/driver-login', [AuthController::class, 'driverLogin'])
        ->middleware('throttle:10,1')
        ->name('driver.login.store');
});

Route::post('/logout', [AuthController::class, 'logout'])
    ->middleware('auth')
    ->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/driver', [RestaurantDriverController::class, 'dashboard'])->name('driver.dashboard');
    Route::get('/driver/orders-feed', [RestaurantDriverController::class, 'feed'])->name('driver.orders.feed');
    Route::patch('/driver/delivery-offers/{offer}/accept', [RestaurantDriverController::class, 'acceptOffer'])->name('driver.delivery-offers.accept');
    Route::patch('/driver/delivery-offers/{offer}/reject', [RestaurantDriverController::class, 'rejectOffer'])->name('driver.delivery-offers.reject');
    Route::patch('/driver/orders/{order}/status', [RestaurantDriverController::class, 'updateStatus'])->name('driver.orders.status');
    Route::patch('/driver/orders/{order}/delivery-time', [RestaurantDriverController::class, 'updateDeliveryTime'])->name('driver.orders.delivery-time');
    Route::post('/driver/push/subscription', [WebPushSubscriptionController::class, 'storeDriver'])->name('driver.push.store');
    Route::delete('/driver/push/subscription', [WebPushSubscriptionController::class, 'destroyDriver'])->name('driver.push.destroy');
});

Route::get('/display', [ScreenController::class, 'mainDisplay'])->name('display.main');
Route::get('/display/shop/{shop}', [ScreenController::class, 'shopDisplay'])->name('display.shop');

Route::middleware(['auth', 'admin.access'])->group(function () {
    Route::get('/push-notifications', [PushNotificationController::class, 'index'])->name('push-notifications.index');
    Route::post('/push-notifications', [PushNotificationController::class, 'send'])->name('push-notifications.send');
    Route::get('/shops/{shop}/salon-appointments', [SalonAppointmentController::class, 'index'])->name('salon-appointments.index');
    Route::patch('/shops/{shop}/salon-appointments/{appointment}/status', [SalonAppointmentController::class, 'status'])->name('salon-appointments.status');
    Route::get('/shops/{shop}/real-estate', [ModularServiceDashboardController::class, 'index'])->name('real-estate.dashboard');
    Route::get('/shops/{shop}/real-estate/categories/create', [ModularServiceDashboardController::class, 'createCategory'])->name('real-estate.dashboard.categories.create');
    Route::post('/shops/{shop}/real-estate/categories', [ModularServiceDashboardController::class, 'storeCategory'])->name('real-estate.dashboard.categories.store');
    Route::get('/shops/{shop}/real-estate/categories/{category}/edit', [ModularServiceDashboardController::class, 'editCategory'])->name('real-estate.dashboard.categories.edit');
    Route::put('/shops/{shop}/real-estate/categories/{category}', [ModularServiceDashboardController::class, 'updateCategory'])->name('real-estate.dashboard.categories.update');
    Route::delete('/shops/{shop}/real-estate/categories/{category}', [ModularServiceDashboardController::class, 'destroyCategory'])->name('real-estate.dashboard.categories.destroy');
    Route::get('/shops/{shop}/real-estate/services/create', [ModularServiceDashboardController::class, 'createService'])->name('real-estate.dashboard.services.create');
    Route::post('/shops/{shop}/real-estate/services', [ModularServiceDashboardController::class, 'storeService'])->name('real-estate.dashboard.services.store');
    Route::get('/shops/{shop}/real-estate/services/{service}/edit', [ModularServiceDashboardController::class, 'editService'])->name('real-estate.dashboard.services.edit');
    Route::put('/shops/{shop}/real-estate/services/{service}', [ModularServiceDashboardController::class, 'updateService'])->name('real-estate.dashboard.services.update');
    Route::delete('/shops/{shop}/real-estate/services/{service}', [ModularServiceDashboardController::class, 'destroyService'])->name('real-estate.dashboard.services.destroy');
    Route::delete('/shops/{shop}/real-estate/service-images/{image}', [ModularServiceDashboardController::class, 'destroyServiceImage'])->name('real-estate.dashboard.service-images.destroy');
    Route::patch('/shops/{shop}/real-estate/service-requests/{serviceRequest}', [ModularServiceDashboardController::class, 'updateRequest'])->name('real-estate.dashboard.service-requests.update');
    Route::get('/shops/{shop}/real-estate/properties/create', [RealEstateDashboardController::class, 'create'])->name('real-estate.dashboard.properties.create');
    Route::post('/shops/{shop}/real-estate/properties', [RealEstateDashboardController::class, 'store'])->name('real-estate.dashboard.properties.store');
    Route::get('/shops/{shop}/real-estate/properties/{property}/edit', [RealEstateDashboardController::class, 'edit'])->name('real-estate.dashboard.properties.edit');
    Route::put('/shops/{shop}/real-estate/properties/{property}', [RealEstateDashboardController::class, 'update'])->name('real-estate.dashboard.properties.update');
    Route::delete('/shops/{shop}/real-estate/properties/{property}', [RealEstateDashboardController::class, 'destroy'])->name('real-estate.dashboard.properties.destroy');
    Route::delete('/shops/{shop}/real-estate/properties/{property}/images/{image}', [RealEstateDashboardController::class, 'destroyImage'])->name('real-estate.dashboard.images.destroy');
    Route::patch('/shops/{shop}/real-estate/properties/{property}/images/{image}/cover', [RealEstateDashboardController::class, 'coverImage'])->name('real-estate.dashboard.images.cover');
    Route::patch('/shops/{shop}/real-estate/properties/{property}/images/{image}/move', [RealEstateDashboardController::class, 'moveImage'])->name('real-estate.dashboard.images.move');
    Route::get('/shops/{shop}/real-estate/properties/{property}/facebook-images', [RealEstateDashboardController::class, 'facebookImages'])->name('real-estate.dashboard.facebook-images');
    Route::patch('/shops/{shop}/real-estate/leads/{lead}', [RealEstateDashboardController::class, 'updateLead'])->name('real-estate.dashboard.leads.update');
    Route::get('/shops/{shop}/restaurant', [RestaurantController::class, 'dashboard'])->name('restaurant.dashboard');
    Route::get('/shops/{shop}/restaurant/customers', [RestaurantController::class, 'customers'])->name('restaurant.customers.index');
    Route::get('/shops/{shop}/restaurant/tables', [RestaurantController::class, 'tables'])->name('restaurant.tables.index');
    Route::get('/shops/{shop}/restaurant/orders/{order}', [RestaurantController::class, 'showOrder'])->name('restaurant.orders.show');
    Route::get('/shops/{shop}/restaurant/orders-feed', [RestaurantController::class, 'ordersFeed'])->name('restaurant.orders.feed');
    Route::patch('/shops/{shop}/restaurant/availability', [RestaurantController::class, 'availability'])->name('restaurant.availability');
    Route::post('/shops/{shop}/restaurant/tables', [RestaurantController::class, 'storeTable'])->name('restaurant.tables.store');
    Route::delete('/restaurant-tables/{table}', [RestaurantController::class, 'destroyTable'])->name('restaurant.tables.destroy');
    Route::patch('/restaurant-orders/{order}/status', [RestaurantController::class, 'status'])->name('restaurant.orders.status');
    Route::get('/shops/{shop}/restaurant/drivers', [RestaurantDriverController::class, 'index'])->name('restaurant.drivers.index');
    Route::post('/shops/{shop}/restaurant/drivers', [RestaurantDriverController::class, 'store'])->name('restaurant.drivers.store');
    Route::patch('/restaurant-drivers/{driver}/status', [RestaurantDriverController::class, 'toggle'])->name('restaurant.drivers.toggle');
    Route::patch('/restaurant-orders/{order}/driver', [RestaurantDriverController::class, 'assign'])->name('restaurant.orders.driver');
    Route::get('/dashboard', [AuthController::class, 'dashboard'])->name('dashboard');

    Route::get('/dashboard/main', function () {
        if (auth()->user()?->isShopOwner() && auth()->user()->shops()->exists()) {
            return redirect()->route('shops.show', auth()->user()->shops()->first());
        }

        if (auth()->user()?->isAgent() || auth()->user()?->isDistributor()) {
            return redirect()->route('products');
        }

        return view('admin.dashboard_main');
    })->name('dashboard.main');

    Route::post('/translations/suggest', [TranslationController::class, 'suggest'])->name('translations.suggest');

    Route::get('/ads', [AdvertisementController::class, 'index'])->name('ads');
    Route::get('/ads/create', [AdvertisementController::class, 'create'])->name('ads.create');
    Route::post('/ads/store', [AdvertisementController::class, 'store'])->name('ads.store');
    Route::get('/ads/{ad}/edit', [AdvertisementController::class, 'edit'])->name('ads.edit');
    Route::put('/ads/{ad}', [AdvertisementController::class, 'update'])->name('ads.update');
    Route::delete('/ads/{ad}', [AdvertisementController::class, 'destroy'])->name('ads.destroy');
    Route::get('/ads/{ad}', [AdvertisementController::class, 'show'])->name('ads.show');

    Route::get('/agents', [AgentController::class, 'index'])->name('agents');
    Route::get('/agents/create', [AgentController::class, 'create'])->name('agents.create');
    Route::post('/agents/store', [AgentController::class, 'store'])->name('agents.store');
    Route::get('/agents/{agent}/edit', [AgentController::class, 'edit'])->name('agents.edit');
    Route::put('/agents/{agent}', [AgentController::class, 'update'])->name('agents.update');
    Route::delete('/agents/{agent}', [AgentController::class, 'destroy'])->name('agents.destroy');
    Route::get('/agents/{agent}/permissions', [AgentController::class, 'editPermissions'])->name('agents.permissions.edit');
    Route::put('/agents/{agent}/permissions', [AgentController::class, 'updatePermissions'])->name('agents.permissions.update');
    Route::get('/agents/{agent}', [AgentController::class, 'show'])->name('agents.show');

    Route::get('/categories', [CategoryController::class, 'index'])->name('categories');
    Route::get('/categories/create', [CategoryController::class, 'create'])->name('categories.create');
    Route::post('/categories/store', [CategoryController::class, 'store'])->name('categories.store');
    Route::get('/categories/{category}/edit', [CategoryController::class, 'edit'])->name('categories.edit');
    Route::put('/categories/{category}', [CategoryController::class, 'update'])->name('categories.update');
    Route::delete('/categories/{category}', [CategoryController::class, 'destroy'])->name('categories.destroy');
    Route::get('/categories/{category}', [CategoryController::class, 'show'])->name('categories.show');

    Route::get('/distributors', [DistributorController::class, 'index'])->name('distributors');
    Route::get('/distributors/create', [DistributorController::class, 'create'])->name('distributors.create');
    Route::post('/distributors/store', [DistributorController::class, 'store'])->name('distributors.store');
    Route::get('/distributors/{distributor}/edit', [DistributorController::class, 'edit'])->name('distributors.edit');
    Route::put('/distributors/{distributor}', [DistributorController::class, 'update'])->name('distributors.update');
    Route::delete('/distributors/{distributor}', [DistributorController::class, 'destroy'])->name('distributors.destroy');
    Route::get('/distributor-marketers', [DistributorController::class, 'marketersIndex'])->name('distributors.marketers.index');
    Route::post('/distributors/{distributor}/marketers', [DistributorController::class, 'storeMarketer'])->name('distributors.marketers.store');
    Route::get('/distributors/{distributor}/permissions', [DistributorController::class, 'editPermissions'])->name('distributors.permissions.edit');
    Route::put('/distributors/{distributor}/permissions', [DistributorController::class, 'updatePermissions'])->name('distributors.permissions.update');
    Route::get('/distributor-marketers/{marketer}/permissions', [DistributorController::class, 'editMarketerPermissions'])->name('distributors.marketers.permissions.edit');
    Route::put('/distributor-marketers/{marketer}/permissions', [DistributorController::class, 'updateMarketerPermissions'])->name('distributors.marketers.permissions.update');
    Route::put('/distributor-marketers/{marketer}', [DistributorController::class, 'updateMarketer'])->name('distributors.marketers.update');
    Route::patch('/distributor-marketers/{marketer}/commission', [DistributorController::class, 'updateMarketerCommission'])->name('distributors.marketers.commission.update');
    Route::delete('/distributor-marketers/{marketer}', [DistributorController::class, 'destroyMarketer'])->name('distributors.marketers.destroy');
    Route::get('/distributors/{distributor}', [DistributorController::class, 'show'])->name('distributors.show');

    Route::get('/products', [ProductController::class, 'index'])->name('products');
    Route::get('/products/preview/storefront', [FrontController::class, 'dashboardPreview'])->name('products.preview');
    Route::get('/products/create', [ProductController::class, 'create'])->name('products.create');
    Route::post('/products/store', [ProductController::class, 'store'])->name('products.store');
    Route::get('/products/{product}/edit', [ProductController::class, 'edit'])->name('products.edit');
    Route::put('/products/{product}', [ProductController::class, 'update'])->name('products.update');
    Route::patch('/products/{product}/quick-settings', [ProductController::class, 'quickSettings'])->name('products.quick-settings');
    Route::delete('/products/{product}', [ProductController::class, 'destroy'])->name('products.destroy');
    Route::get('/products/{product}', [ProductController::class, 'show'])->name('products.show');

    Route::get('/screens', [ScreenController::class, 'index'])->name('screens');
    Route::get('/screens/create', [ScreenController::class, 'create'])->name('screens.create');
    Route::post('/screens/store', [ScreenController::class, 'store'])->name('screens.store');
    Route::get('/screens/{screen}/edit', [ScreenController::class, 'edit'])->name('screens.edit');
    Route::put('/screens/{screen}', [ScreenController::class, 'update'])->name('screens.update');
    Route::delete('/screens/{screen}', [ScreenController::class, 'destroy'])->name('screens.destroy');
    Route::get('/screens/{screen}', [ScreenController::class, 'show'])->name('screens.show');

    Route::get('/settings', [SettingsController::class, 'index'])->name('settings');
    Route::put('/settings/profile', [SettingsController::class, 'updateProfile'])->name('settings.profile.update');
    Route::put('/settings/password', [SettingsController::class, 'updatePassword'])->name('settings.password.update');
    Route::put('/settings/system', [SettingsController::class, 'updateSystem'])->name('settings.system.update');
    Route::put('/settings/notifications', [SettingsController::class, 'updateNotifications'])->name('settings.notifications.update');

    Route::post('/admin-notifications/read-all', function () {
        abort_unless(auth()->user()?->isSuperAdmin() || (auth()->user()?->isEmployee() && auth()->user()?->canAccessRouteName('admin.notifications.readAll')), 403);

        AdminNotification::query()
            ->whereNull('read_at')
            ->update(['read_at' => now()]);

        return back();
    })->name('admin.notifications.readAll');

    Route::get('/shops', [ShopController::class, 'index'])->name('shops');
    Route::get('/shops/create', [ShopController::class, 'create'])->name('shops.create');
    Route::get('/shops/ozman', [ShopController::class, 'ozman'])->name('shops.ozman');
    Route::post('/shops/store', [ShopController::class, 'store'])->name('shops.store');
    Route::post('/shops/{shop}/enter-dashboard', [AuthController::class, 'enterShopDashboard'])
        ->name('shops.enter-dashboard');
    Route::patch('/shops/{shop}/distributor', [ShopController::class, 'assignDistributor'])
        ->name('shops.distributor.assign');
    Route::get('/shops/{shop}/permissions', [ShopController::class, 'editOwnerPermissions'])
        ->name('shops.permissions.edit');
    Route::put('/shops/{shop}/permissions', [ShopController::class, 'updateOwnerPermissions'])
        ->name('shops.permissions.update');
    Route::post('/admin/return-from-shop', [AuthController::class, 'returnFromShopDashboard'])
        ->name('admin.return-from-shop');
    Route::get('/shops/{shop}/edit', [ShopController::class, 'edit'])->name('shops.edit');
    Route::put('/shops/{shop}', [ShopController::class, 'update'])->name('shops.update');
    Route::delete('/shops/{shop}', [ShopController::class, 'destroy'])->name('shops.destroy');
    Route::get('/shops/{shop}', [ShopController::class, 'show'])->name('shops.show');

    Route::get('/users', function () {
        abort_unless(
            auth()->user()?->isSuperAdmin()
                || (auth()->user()?->isEmployee() && auth()->user()?->canAccessRouteName('users')),
            403
        );

        return view('admin.users');
    })->name('users');

    Route::get('/employees', [EmployeeController::class, 'index'])->name('employees');
    Route::get('/employees/create', [EmployeeController::class, 'create'])->name('employees.create');
    Route::post('/employees', [EmployeeController::class, 'store'])->name('employees.store');
    Route::get('/employees/{employee}/edit', [EmployeeController::class, 'edit'])->name('employees.edit');
    Route::put('/employees/{employee}', [EmployeeController::class, 'update'])->name('employees.update');
    Route::delete('/employees/{employee}', [EmployeeController::class, 'destroy'])->name('employees.destroy');
    Route::get('/employees/{employee}/permissions', [EmployeeController::class, 'editPermissions'])->name('employees.permissions.edit');
    Route::put('/employees/{employee}/permissions', [EmployeeController::class, 'updatePermissions'])->name('employees.permissions.update');

    Route::get('/visitor-registrations', [VisitorRegistrationAdminController::class, 'index'])
        ->name('visitor-registrations.index');
    Route::patch('/visitor-registrations/{registration}/status', [VisitorRegistrationAdminController::class, 'status'])
        ->name('visitor-registrations.status.update');

    Route::get('/front-orders', [FrontOrderController::class, 'index'])
        ->name('front-orders.index');
    Route::patch('/front-orders/{order}/status', [FrontOrderController::class, 'status'])
        ->name('front-orders.status');

    Route::get('/raffle-cards', [RaffleCardController::class, 'index'])
        ->name('raffle-cards.index');
    Route::get('/raffle-cards/inspector', [RaffleCardController::class, 'inspector'])
        ->name('raffle-cards.inspector');
    Route::get('/raffle-cards/export/pdf', [RaffleCardController::class, 'exportWinningCardsPdf'])
        ->name('raffle-cards.export-pdf');
    Route::post('/raffle-cards', [RaffleCardController::class, 'store'])
        ->name('raffle-cards.store');
    Route::post('/raffle-cards/random-bulk', [RaffleCardController::class, 'storeRandomBulk'])
        ->name('raffle-cards.random-bulk');
    Route::post('/raffle-cards/printable', [RaffleCardController::class, 'printable'])
        ->name('raffle-cards.printable');
    Route::post('/raffle-cards/live-draw/random', [RaffleCardController::class, 'randomLiveDraw'])
        ->name('raffle-cards.live-draw.random');
    Route::delete('/raffle-cards/live-draw/bulk', [RaffleCardController::class, 'bulkDestroyLiveEntries'])
        ->name('raffle-cards.live-draw.bulk-destroy');
    Route::delete('/raffle-cards/live-draw/{entry}', [RaffleCardController::class, 'destroyLiveEntry'])
        ->name('raffle-cards.live-draw.destroy');
    Route::delete('/raffle-cards/bulk', [RaffleCardController::class, 'bulkDestroy'])
        ->name('raffle-cards.bulk-destroy');
    Route::put('/raffle-cards/settings', [RaffleCardController::class, 'updateSettings'])
        ->name('raffle-cards.settings');
    Route::put('/raffle-cards/{card}', [RaffleCardController::class, 'update'])
        ->name('raffle-cards.update');
    Route::delete('/raffle-cards/{card}', [RaffleCardController::class, 'destroy'])
        ->name('raffle-cards.destroy');

    Route::get('/reward-wheels/customer-signup', [RewardWheelController::class, 'edit'])
        ->name('reward-wheels.customer-signup.edit');
    Route::get('/shops/{shop}/signup-wheel', [RewardWheelController::class, 'shopSignupEdit'])->name('reward-wheels.shop-signup.edit');
    Route::put('/shops/{shop}/signup-wheel', [RewardWheelController::class, 'shopSignupUpdate'])->name('reward-wheels.shop-signup.update');
    Route::put('/reward-wheels/customer-signup', [RewardWheelController::class, 'update'])
        ->name('reward-wheels.customer-signup.update');
    Route::get('/reward-wheels/purchase', [RewardWheelController::class, 'purchaseIndex'])
        ->name('reward-wheels.purchase.index');
    Route::post('/reward-wheels/purchase', [RewardWheelController::class, 'purchaseStore'])
        ->name('reward-wheels.purchase.store');
    Route::get('/reward-wheels/purchase/{wheel}/edit', [RewardWheelController::class, 'purchaseEdit'])
        ->name('reward-wheels.purchase.edit');
    Route::put('/reward-wheels/purchase/{wheel}', [RewardWheelController::class, 'purchaseUpdate'])
        ->name('reward-wheels.purchase.update');
    Route::delete('/reward-wheels/purchase/{wheel}', [RewardWheelController::class, 'purchaseDestroy'])
        ->name('reward-wheels.purchase.destroy');
    Route::get('/reward-wheels/marketer/settings', [RewardWheelController::class, 'marketerEdit'])
        ->name('reward-wheels.marketer.edit');
    Route::put('/reward-wheels/marketer/settings', [RewardWheelController::class, 'marketerUpdate'])
        ->name('reward-wheels.marketer.update');
    Route::delete('/reward-wheels/marketer/segments/{segment}', [RewardWheelController::class, 'marketerSegmentDestroy'])
        ->name('reward-wheels.marketer.segments.destroy');
    Route::get('/reward-wheels/marketer/play', [RewardWheelController::class, 'marketerPlay'])
        ->name('reward-wheels.marketer.play');
    Route::post('/reward-wheels/marketer/unlock', [RewardWheelController::class, 'marketerUnlock'])
        ->name('reward-wheels.marketer.unlock');
    Route::post('/reward-wheels/marketer/spin', [RewardWheelController::class, 'marketerSpin'])
        ->name('reward-wheels.marketer.spin');
    Route::post('/reward-wheels/marketer/reset', [RewardWheelController::class, 'marketerReset'])
        ->name('reward-wheels.marketer.reset');
    Route::get('/reward-wheels/marketer/direct/settings', [RewardWheelController::class, 'marketerDirectEdit'])
        ->name('reward-wheels.marketer.direct.edit');
    Route::put('/reward-wheels/marketer/direct/settings', [RewardWheelController::class, 'marketerDirectUpdate'])
        ->name('reward-wheels.marketer.direct.update');
    Route::delete('/reward-wheels/marketer/direct/segments/{segment}', [RewardWheelController::class, 'marketerDirectSegmentDestroy'])
        ->name('reward-wheels.marketer.direct.segments.destroy');
    Route::get('/reward-wheels/marketer/direct/play', [RewardWheelController::class, 'marketerDirectPlay'])
        ->name('reward-wheels.marketer.direct.play');
    Route::post('/reward-wheels/marketer/direct/spin', [RewardWheelController::class, 'marketerDirectSpin'])
        ->name('reward-wheels.marketer.direct.spin');
});

Route::get('/lang/{locale}', [\App\Http\Controllers\LanguageController::class, 'switch'])->name('lang.switch');
